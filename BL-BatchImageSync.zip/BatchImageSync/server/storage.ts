import { users, uploadSessions, type User, type InsertUser, type UploadSession, type InsertUploadSession } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createUploadSession(session: InsertUploadSession): Promise<UploadSession>;
  getUploadSessions(): Promise<UploadSession[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private uploadSessions: Map<number, UploadSession>;
  private currentUserId: number;
  private currentSessionId: number;

  constructor() {
    this.users = new Map();
    this.uploadSessions = new Map();
    this.currentUserId = 1;
    this.currentSessionId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createUploadSession(insertSession: InsertUploadSession): Promise<UploadSession> {
    const id = this.currentSessionId++;
    const session: UploadSession = { ...insertSession, id };
    this.uploadSessions.set(id, session);
    return session;
  }

  async getUploadSessions(): Promise<UploadSession[]> {
    return Array.from(this.uploadSessions.values());
  }
}

export const storage = new MemStorage();
