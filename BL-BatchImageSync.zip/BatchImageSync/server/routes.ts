import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUploadSessionSchema } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import AWS from "aws-sdk";
import path from "path";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG and PNG allowed.'));
    }
  }
});

// Configure AWS S3
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
});

const BUCKET_NAME = process.env.S3_BUCKET_NAME;

const generateFileName = (prefix: string, code: string, index: number, originalName: string) => {
  const ext = path.extname(originalName);
  return `${prefix}_${code}_${index}${ext}`;
};

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Upload images route
  app.post('/api/upload', upload.array('images', 20), async (req, res) => {
    try {
      const { prefix, code, folderName } = req.body;
      
      // Validation
      if (!prefix || !code || !folderName || !req.files || req.files.length === 0) {
        return res.status(400).json({ 
          error: 'Missing required fields: prefix, code, folderName, or images' 
        });
      }

      if (!['BA', 'BU'].includes(prefix)) {
        return res.status(400).json({ error: 'Invalid prefix. Must be BA or BU' });
      }

      if (!/^\d+$/.test(code)) {
        return res.status(400).json({ error: 'Code must be numeric' });
      }

      const files = req.files as Express.Multer.File[];
      const uploadPromises = files.map(async (file, index) => {
        const newFileName = generateFileName(prefix, code, index + 1, file.originalname);
        const s3Key = `${folderName}/${newFileName}`;
        
        const params = {
          Bucket: BUCKET_NAME,
          Key: s3Key,
          Body: file.buffer,
          ContentType: file.mimetype,
          ACL: 'private' as const
        };

        const result = await s3.upload(params).promise();
        return {
          originalName: file.originalname,
          newName: newFileName,
          s3Location: result.Location,
          key: result.Key
        };
      });

      const uploadResults = await Promise.all(uploadPromises);
      
      // Store upload session
      await storage.createUploadSession({
        prefix,
        code,
        folderName,
        fileCount: uploadResults.length,
        status: 'completed'
      });
      
      res.json({
        success: true,
        message: `Successfully uploaded ${uploadResults.length} files`,
        folderName,
        files: uploadResults
      });

    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ 
        error: 'Upload failed', 
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Get upload sessions
  app.get('/api/sessions', async (req, res) => {
    try {
      const sessions = await storage.getUploadSessions();
      res.json({ sessions });
    } catch (error) {
      console.error('Sessions error:', error);
      res.status(500).json({ error: 'Failed to get sessions' });
    }
  });

  // List folders
  app.get('/api/folders', async (req, res) => {
    try {
      const params = {
        Bucket: BUCKET_NAME,
        Delimiter: '/'
      };

      const result = await s3.listObjectsV2(params).promise();
      const folders = result.CommonPrefixes?.map(prefix => prefix.Prefix?.slice(0, -1)) || [];
      
      res.json({ folders });
    } catch (error) {
      console.error('Folder list error:', error);
      res.status(500).json({ error: 'Failed to list folders' });
    }
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date().toISOString() });
  });

  // Error handling middleware
  app.use((error: any, req: any, res: any, next: any) => {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ error: 'File too large. Maximum 10MB allowed.' });
    }
    res.status(500).json({ error: error.message });
  });

  const httpServer = createServer(app);
  return httpServer;
}
