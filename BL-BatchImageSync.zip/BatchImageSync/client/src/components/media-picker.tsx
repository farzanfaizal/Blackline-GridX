import { useRef } from "react";

interface MediaPickerProps {
  onCameraPress: () => void;
  onGallerySelect: (files: FileList) => void;
}

export function MediaPicker({ onCameraPress, onGallerySelect }: MediaPickerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGalleryClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      onGallerySelect(files);
    }
    // Reset input value to allow selecting same files again
    event.target.value = '';
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-on-surface">Add Media</h3>
      <div className="grid grid-cols-2 gap-3">
        <button 
          className="bg-primary hover:bg-blue-700 text-on-primary p-4 rounded-lg shadow-material flex flex-col items-center space-y-2 transition-colors"
          onClick={onCameraPress}
        >
          <i className="fas fa-camera text-xl"></i>
          <span className="text-sm font-medium">Camera</span>
        </button>
        <button 
          className="bg-secondary hover:bg-teal-700 text-on-primary p-4 rounded-lg shadow-material flex flex-col items-center space-y-2 transition-colors"
          onClick={handleGalleryClick}
        >
          <i className="fas fa-images text-xl"></i>
          <span className="text-sm font-medium">Gallery</span>
        </button>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png"
        multiple
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
