import { useState, useRef, useEffect } from "react";

interface CameraModalProps {
  isVisible: boolean;
  onCapture: (imageFile: File) => void;
  onClose: () => void;
}

export function CameraModal({ isVisible, onCapture, onClose }: CameraModalProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("environment");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (isVisible) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isVisible, facingMode]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode }
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Error accessing camera. Please ensure you have granted camera permissions.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const switchCamera = () => {
    setFacingMode(prev => prev === "user" ? "environment" : "user");
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    canvas.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], `photo_${Date.now()}.jpg`, { type: 'image/jpeg' });
        onCapture(file);
      }
    }, 'image/jpeg', 0.8);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
      <div className="absolute inset-0 bg-black flex flex-col">
        {/* Camera Controls */}
        <div className="flex justify-between items-center p-4 text-white">
          <button onClick={onClose} className="text-xl">
            <i className="fas fa-times"></i>
          </button>
          <span className="font-medium">Camera</span>
          <button onClick={switchCamera} className="text-xl">
            <i className="fas fa-sync-alt"></i>
          </button>
        </div>

        {/* Camera Preview Area */}
        <div className="flex-1 relative bg-gray-900 flex items-center justify-center">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
            style={{ transform: facingMode === "user" ? "scaleX(-1)" : "none" }}
          />
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Camera Actions */}
        <div className="p-6 flex justify-center">
          <button 
            className="bg-white rounded-full w-16 h-16 flex items-center justify-center shadow-material-lg"
            onClick={capturePhoto}
          >
            <i className="fas fa-camera text-2xl text-gray-800"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
