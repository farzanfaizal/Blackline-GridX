interface SyncButtonProps {
  isUploading: boolean;
  onSync: () => void;
  disabled: boolean;
}

export function SyncButton({ isUploading, onSync, disabled }: SyncButtonProps) {
  return (
    <div className="pt-4 pb-8">
      <button 
        className={`w-full p-4 rounded-lg shadow-material-lg flex items-center justify-center space-x-2 transition-colors font-semibold ${
          disabled || isUploading
            ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
            : 'bg-success hover:bg-green-600 text-on-primary'
        }`}
        onClick={onSync}
        disabled={disabled || isUploading}
      >
        {isUploading ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            <span>Uploading images...</span>
          </>
        ) : (
          <>
            <i className="fas fa-cloud-upload-alt text-lg"></i>
            <span>Sync Images to Cloud</span>
          </>
        )}
      </button>
    </div>
  );
}
