import { SelectedImage } from "@/pages/home";

interface ImagePreviewProps {
  images: SelectedImage[];
  prefix: string;
  code: string;
  onRemoveImage: (id: string) => void;
}

export function ImagePreview({ images, prefix, code, onRemoveImage }: ImagePreviewProps) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-on-surface">Selected Images</h3>
        <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
          {images.length}
        </span>
      </div>
      
      <div className="grid grid-cols-3 gap-3">
        {images.map((image) => (
          <div key={image.id} className="relative">
            <img 
              src={image.url} 
              alt={image.file.name}
              className="w-full h-20 object-cover rounded-lg shadow-material"
            />
            <button 
              className="absolute -top-2 -right-2 bg-error text-white rounded-full w-6 h-6 flex items-center justify-center shadow-material text-xs"
              onClick={() => onRemoveImage(image.id)}
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
        ))}
      </div>

      {/* Preview Details */}
      <div className="bg-gray-50 rounded-lg p-3 text-sm">
        <p className="text-gray-700 mb-1">Files will be renamed as:</p>
        <div className="space-y-1 text-gray-600">
          {images.slice(0, 3).map((image, index) => (
            <div key={image.id} className="flex justify-between">
              <span className="truncate max-w-[120px]">{image.file.name}</span>
              <span>→</span>
              <span className="font-medium">{prefix}_{code}_{index + 1}.{image.file.name.split('.').pop()}</span>
            </div>
          ))}
          {images.length > 3 && (
            <div className="text-gray-500 text-center">
              ... and {images.length - 3} more files
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
