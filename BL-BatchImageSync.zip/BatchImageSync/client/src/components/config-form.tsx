import { useEffect } from "react";

interface ConfigFormProps {
  prefix: "BA" | "BU";
  code: string;
  folderName: string;
  onPrefixChange: (prefix: "BA" | "BU") => void;
  onCodeChange: (code: string) => void;
  onFolderNameChange: (folderName: string) => void;
}

export function ConfigForm({
  prefix,
  code,
  folderName,
  onPrefixChange,
  onCodeChange,
  onFolderNameChange
}: ConfigFormProps) {
  
  // Auto-update folder name when prefix or code changes
  useEffect(() => {
    if (code.trim()) {
      onFolderNameChange(`${prefix}_${code.trim()}`);
    } else {
      onFolderNameChange('');
    }
  }, [prefix, code, onFolderNameChange]);

  return (
    <div className="space-y-4">
      {/* Step 1: Prefix Selection */}
      <div className="bg-surface rounded-lg p-4 shadow-material">
        <label className="block text-sm font-medium text-on-surface mb-2">
          <span className="bg-primary text-on-primary rounded-full w-6 h-6 inline-flex items-center justify-center text-xs mr-2">1</span>
          Select Prefix
        </label>
        <div className="relative">
          <select 
            className="w-full p-3 border border-gray-300 rounded-lg bg-surface focus:ring-2 focus:ring-primary focus:border-primary appearance-none"
            value={prefix}
            onChange={(e) => onPrefixChange(e.target.value as "BA" | "BU")}
          >
            <option value="BA">BA</option>
            <option value="BU">BU</option>
          </select>
          <i className="fas fa-chevron-down absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none"></i>
        </div>
      </div>

      {/* Step 2: Code Input */}
      <div className="bg-surface rounded-lg p-4 shadow-material">
        <label className="block text-sm font-medium text-on-surface mb-2">
          <span className="bg-primary text-on-primary rounded-full w-6 h-6 inline-flex items-center justify-center text-xs mr-2">2</span>
          Enter Code Number
        </label>
        <input 
          type="number" 
          className="w-full p-3 border border-gray-300 rounded-lg bg-surface focus:ring-2 focus:ring-primary focus:border-primary" 
          placeholder="123"
          value={code}
          onChange={(e) => onCodeChange(e.target.value)}
        />
        <p className="text-xs text-gray-500 mt-1">Numeric code only</p>
      </div>

      {/* Step 3: Folder Name */}
      <div className="bg-surface rounded-lg p-4 shadow-material">
        <label className="block text-sm font-medium text-on-surface mb-2">
          <span className="bg-primary text-on-primary rounded-full w-6 h-6 inline-flex items-center justify-center text-xs mr-2">3</span>
          Confirm Folder Name
        </label>
        <input 
          type="text" 
          className="w-full p-3 border border-gray-300 rounded-lg bg-surface focus:ring-2 focus:ring-primary focus:border-primary" 
          placeholder={code ? `${prefix}_${code}` : 'Folder name'}
          value={folderName}
          onChange={(e) => onFolderNameChange(e.target.value)}
        />
        <p className="text-xs text-gray-500 mt-1">Auto-generated from prefix and code</p>
      </div>
    </div>
  );
}
