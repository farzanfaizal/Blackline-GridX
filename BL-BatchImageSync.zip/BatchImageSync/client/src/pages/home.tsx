import { useState } from "react";
import { ConfigForm } from "@/components/config-form";
import { MediaPicker } from "@/components/media-picker";
import { ImagePreview } from "@/components/image-preview";
import { SyncButton } from "@/components/sync-button";
import { CameraModal } from "@/components/camera-modal";

export interface SelectedImage {
  file: File;
  url: string;
  id: string;
}

export default function Home() {
  const [prefix, setPrefix] = useState<"BA" | "BU">("BA");
  const [code, setCode] = useState("");
  const [folderName, setFolderName] = useState("");
  const [selectedImages, setSelectedImages] = useState<SelectedImage[]>([]);
  const [showCamera, setShowCamera] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  const handleCameraCapture = (imageFile: File) => {
    const imageUrl = URL.createObjectURL(imageFile);
    const newImage: SelectedImage = {
      file: imageFile,
      url: imageUrl,
      id: Date.now().toString()
    };
    setSelectedImages(prev => [...prev, newImage]);
    setShowCamera(false);
  };

  const handleGallerySelect = (files: FileList) => {
    const newImages: SelectedImage[] = Array.from(files).map(file => ({
      file,
      url: URL.createObjectURL(file),
      id: Date.now().toString() + Math.random()
    }));
    setSelectedImages(prev => [...prev, ...newImages]);
  };

  const handleRemoveImage = (id: string) => {
    setSelectedImages(prev => {
      const imageToRemove = prev.find(img => img.id === id);
      if (imageToRemove) {
        URL.revokeObjectURL(imageToRemove.url);
      }
      return prev.filter(img => img.id !== id);
    });
  };

  const handleSync = async () => {
    if (!code.trim() || !folderName.trim() || selectedImages.length === 0) {
      return;
    }

    setIsUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('prefix', prefix);
      formData.append('code', code.trim());
      formData.append('folderName', folderName.trim());

      selectedImages.forEach((image, index) => {
        formData.append('images', image.file, image.file.name);
      });

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      
      if (result.success) {
        // Clear form
        setCode('');
        setFolderName('');
        setSelectedImages([]);
        
        // Show success message via toast
        const event = new CustomEvent('showToast', {
          detail: {
            title: 'Upload Successful!',
            description: `${result.files.length} images uploaded to ${result.folderName} folder`,
            type: 'success'
          }
        });
        window.dispatchEvent(event);
      } else {
        throw new Error(result.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      const event = new CustomEvent('showToast', {
        detail: {
          title: 'Upload Failed',
          description: error instanceof Error ? error.message : 'Please check your connection and try again',
          type: 'error'
        }
      });
      window.dispatchEvent(event);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="max-w-sm mx-auto bg-surface min-h-screen shadow-material-lg">
      {/* Status Bar */}
      <div className="bg-primary text-on-primary px-4 py-2 flex justify-between items-center text-sm">
        <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        <span>Image Renamer</span>
        <div className="flex items-center space-x-1">
          <i className="fas fa-wifi text-xs"></i>
          <i className="fas fa-battery-three-quarters text-xs"></i>
        </div>
      </div>

      {/* App Content */}
      <div className="p-4 space-y-6">
        {/* Header */}
        <div className="text-center py-4">
          <h1 className="text-2xl font-bold text-on-surface mb-2">Image Renamer</h1>
          <p className="text-sm text-gray-600">Batch rename and upload images to cloud storage</p>
        </div>

        {/* Configuration Form */}
        <ConfigForm
          prefix={prefix}
          code={code}
          folderName={folderName}
          onPrefixChange={setPrefix}
          onCodeChange={setCode}
          onFolderNameChange={setFolderName}
        />

        {/* Media Picker */}
        <MediaPicker
          onCameraPress={() => setShowCamera(true)}
          onGallerySelect={handleGallerySelect}
        />

        {/* Image Preview */}
        {selectedImages.length > 0 && (
          <ImagePreview
            images={selectedImages}
            prefix={prefix}
            code={code}
            onRemoveImage={handleRemoveImage}
          />
        )}

        {/* Sync Button */}
        <SyncButton
          isUploading={isUploading}
          onSync={handleSync}
          disabled={!code.trim() || !folderName.trim() || selectedImages.length === 0}
        />
      </div>

      {/* Camera Modal */}
      {showCamera && (
        <CameraModal
          isVisible={showCamera}
          onCapture={handleCameraCapture}
          onClose={() => setShowCamera(false)}
        />
      )}
    </div>
  );
}
