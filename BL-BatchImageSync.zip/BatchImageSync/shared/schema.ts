import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const uploadSessions = pgTable("upload_sessions", {
  id: serial("id").primaryKey(),
  prefix: text("prefix").notNull(),
  code: text("code").notNull(),
  folderName: text("folder_name").notNull(),
  fileCount: integer("file_count").notNull(),
  status: text("status").notNull().default("completed"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertUploadSessionSchema = createInsertSchema(uploadSessions).pick({
  prefix: true,
  code: true,
  folderName: true,
  fileCount: true,
  status: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertUploadSession = z.infer<typeof insertUploadSessionSchema>;
export type UploadSession = typeof uploadSessions.$inferSelect;
