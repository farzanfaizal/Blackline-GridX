const express = require('express');
const multer = require('multer');
const AWS = require('aws-sdk');
const path = require('path');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Configure AWS S3
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
});

const BUCKET_NAME = process.env.S3_BUCKET_NAME;

// Configure multer for memory storage
const storage = multer.memoryStorage();
const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG and PNG allowed.'));
    }
  }
});

// Utility function to generate new filename
const generateFileName = (prefix, code, index, originalName) => {
  const ext = path.extname(originalName);
  return `${prefix}_${code}_${index}${ext}`;
};

// Route: Upload and rename files
app.post('/api/upload', upload.array('images', 20), async (req, res) => {
  try {
    const { prefix, code, folderName } = req.body;
    
    // Validation
    if (!prefix || !code || !folderName || !req.files || req.files.length === 0) {
      return res.status(400).json({ 
        error: 'Missing required fields: prefix, code, folderName, or images' 
      });
    }

    if (!['BA', 'BU'].includes(prefix)) {
      return res.status(400).json({ error: 'Invalid prefix. Must be BA or BU' });
    }

    if (!/^\d+$/.test(code)) {
      return res.status(400).json({ error: 'Code must be numeric' });
    }

    const uploadPromises = req.files.map(async (file, index) => {
      const newFileName = generateFileName(prefix, code, index + 1, file.originalname);
      const s3Key = `${folderName}/${newFileName}`;
      
      const params = {
        Bucket: BUCKET_NAME,
        Key: s3Key,
        Body: file.buffer,
        ContentType: file.mimetype,
        ACL: 'private'
      };

      const result = await s3.upload(params).promise();
      return {
        originalName: file.originalname,
        newName: newFileName,
        s3Location: result.Location,
        key: result.Key
      };
    });

    const uploadResults = await Promise.all(uploadPromises);
    
    res.json({
      success: true,
      message: `Successfully uploaded ${uploadResults.length} files`,
      folderName,
      files: uploadResults
    });

  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      error: 'Upload failed', 
      details: error.message 
    });
  }
});

// Route: List folders
app.get('/api/folders', async (req, res) => {
  try {
    const params = {
      Bucket: BUCKET_NAME,
      Delimiter: '/'
    };

    const result = await s3.listObjectsV2(params).promise();
    const folders = result.CommonPrefixes.map(prefix => prefix.Prefix.slice(0, -1));
    
    res.json({ folders });
  } catch (error) {
    console.error('Folder list error:', error);
    res.status(500).json({ error: 'Failed to list folders' });
  }
});

// Route: List files in folder
app.get('/api/folders/:folderName/files', async (req, res) => {
  try {
    const { folderName } = req.params;
    
    const params = {
      Bucket: BUCKET_NAME,
      Prefix: `${folderName}/`
    };

    const result = await s3.listObjectsV2(params).promise();
    const files = result.Contents.map(item => ({
      name: path.basename(item.Key),
      key: item.Key,
      size: item.Size,
      lastModified: item.LastModified
    }));
    
    res.json({ files });
  } catch (error) {
    console.error('Files list error:', error);
    res.status(500).json({ error: 'Failed to list files' });
  }
});

// Route: Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({ error: 'File too large. Maximum 10MB allowed.' });
    }
  }
  res.status(500).json({ error: error.message });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});