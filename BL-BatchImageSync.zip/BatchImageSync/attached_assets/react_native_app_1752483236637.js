import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput, 
  Alert, 
  ScrollView,
  Image,
  ActivityIndicator
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';

const API_BASE_URL = 'https://your-backend-url.onrender.com/api';

export default function App() {
  const [prefix, setPrefix] = useState('BA');
  const [code, setCode] = useState('');
  const [folderName, setFolderName] = useState('');
  const [selectedImages, setSelectedImages] = useState([]);
  const [isUploading, setIsUploading] = useState(false);

  // Request permissions
  const requestPermissions = async () => {
    const { status: cameraStatus } = await ImagePicker.requestCameraPermissionsAsync();
    const { status: mediaStatus } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (cameraStatus !== 'granted' || mediaStatus !== 'granted') {
      Alert.alert('Permission Required', 'Camera and media library permissions are required.');
      return false;
    }
    return true;
  };

  // Take photo with camera
  const takePhoto = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
    });

    if (!result.canceled) {
      setSelectedImages(prev => [...prev, result.assets[0]]);
    }
  };

  // Pick from gallery
  const pickFromGallery = async () => {
    const hasPermission = await requestPermissions();
    if (!hasPermission) return;

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (!result.canceled) {
      setSelectedImages(prev => [...prev, ...result.assets]);
    }
  };

  // Show media options
  const showMediaOptions = () => {
    Alert.alert(
      'Add Media',
      'Choose an option',
      [
        { text: 'Camera', onPress: takePhoto },
        { text: 'Gallery', onPress: pickFromGallery },
        { text: 'Cancel', style: 'cancel' }
      ]
    );
  };

  // Remove image
  const removeImage = (index) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  // Validate form
  const validateForm = () => {
    if (!code.trim()) {
      Alert.alert('Error', 'Please enter a code number');
      return false;
    }
    if (!/^\d+$/.test(code.trim())) {
      Alert.alert('Error', 'Code must be numeric');
      return false;
    }
    if (!folderName.trim()) {
      Alert.alert('Error', 'Please enter a folder name');
      return false;
    }
    if (selectedImages.length === 0) {
      Alert.alert('Error', 'Please select at least one image');
      return false;
    }
    return true;
  };

  // Upload images
  const syncImages = async () => {
    if (!validateForm()) return;

    setIsUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('prefix', prefix);
      formData.append('code', code.trim());
      formData.append('folderName', folderName.trim());

      selectedImages.forEach((image, index) => {
        formData.append('images', {
          uri: image.uri,
          type: 'image/jpeg',
          name: `image_${index}.jpg`
        });
      });

      const response = await fetch(`${API_BASE_URL}/upload`, {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      const result = await response.json();

      if (result.success) {
        Alert.alert(
          'Success', 
          `Uploaded ${result.files.length} images to ${result.folderName}`,
          [{ text: 'OK', onPress: resetForm }]
        );
      } else {
        Alert.alert('Error', result.error || 'Upload failed');
      }
    } catch (error) {
      console.error('Upload error:', error);
      Alert.alert('Error', 'Network error. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setCode('');
    setFolderName('');
    setSelectedImages([]);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Image Renamer</Text>
      
      {/* Prefix Selection */}
      <View style={styles.section}>
        <Text style={styles.label}>1. Select Prefix:</Text>
        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={prefix}
            style={styles.picker}
            onValueChange={setPrefix}
          >
            <Picker.Item label="BA" value="BA" />
            <Picker.Item label="BU" value="BU" />
          </Picker>
        </View>
      </View>

      {/* Code Input */}
      <View style={styles.section}>
        <Text style={styles.label}>2. Enter Code Number:</Text>
        <TextInput
          style={styles.input}
          value={code}
          onChangeText={setCode}
          placeholder="123"
          keyboardType="numeric"
        />
      </View>

      {/* Folder Name */}
      <View style={styles.section}>
        <Text style={styles.label}>3. Confirm Folder Name:</Text>
        <TextInput
          style={styles.input}
          value={folderName}
          onChangeText={setFolderName}
          placeholder={code ? `${prefix}_${code}` : 'Folder name'}
        />
      </View>

      {/* Add Media Button */}
      <TouchableOpacity style={styles.mediaButton} onPress={showMediaOptions}>
        <Text style={styles.mediaButtonText}>Add Media</Text>
      </TouchableOpacity>

      {/* Selected Images */}
      {selectedImages.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.label}>Selected Images ({selectedImages.length}):</Text>
          <ScrollView horizontal style={styles.imageContainer}>
            {selectedImages.map((image, index) => (
              <View key={index} style={styles.imageWrapper}>
                <Image source={{ uri: image.uri }} style={styles.thumbnail} />
                <TouchableOpacity 
                  style={styles.removeButton} 
                  onPress={() => removeImage(index)}
                >
                  <Text style={styles.removeButtonText}>×</Text>
                </TouchableOpacity>
              </View>
            ))}
          </ScrollView>
        </View>
      )}

      {/* Sync Button */}
      <TouchableOpacity 
        style={[styles.syncButton, isUploading && styles.syncButtonDisabled]} 
        onPress={syncImages}
        disabled={isUploading}
      >
        {isUploading ? (
          <ActivityIndicator color="white" />
        ) : (
          <Text style={styles.syncButtonText}>Sync Images</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 20,
    paddingTop: 50,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
    color: '#333',
  },
  section: {
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#333',
  },
  pickerContainer: {
    backgroundColor: 'white',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  picker: {
    height: 50,
  },
  input: {
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  mediaButton: {
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  mediaButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  imageContainer: {
    flexDirection: 'row',
  },
  imageWrapper: {
    position: 'relative',
    marginRight: 10,
  },
  thumbnail: {
    width: 80,
    height: 80,
    borderRadius: 8,
  },
  removeButton: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: 'red',
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  removeButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  syncButton: {
    backgroundColor: '#34C759',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  syncButtonDisabled: {
    backgroundColor: '#999',
  },
  syncButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});