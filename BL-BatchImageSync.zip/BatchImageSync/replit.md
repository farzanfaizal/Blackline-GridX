# replit.md

## Overview

This is a full-stack web application built with TypeScript that allows users to upload and rename images to AWS S3. The application features a React frontend with a modern UI built using shadcn/ui components and Tailwind CSS, and an Express.js backend with PostgreSQL database integration using Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Build Tool**: Vite for development and production builds
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **File Storage**: AWS S3 for image storage
- **File Upload**: Multer for handling multipart/form-data
- **Development**: Hot reloading with Vite middleware integration

## Key Components

### Database Schema
Located in `shared/schema.ts`:
- **users**: User authentication table with username/password
- **upload_sessions**: Tracks file upload sessions with prefix, code, folder name, and file count

### Frontend Components
- **ConfigForm**: Handles prefix selection and code input
- **MediaPicker**: Provides camera and gallery access options
- **CameraModal**: Browser-based camera interface for photo capture
- **ImagePreview**: Shows selected images with rename preview
- **SyncButton**: Triggers upload process to S3

### Backend Routes
- **POST /api/upload**: Handles file upload with automatic renaming based on prefix and code
- File validation for JPEG/PNG formats only
- 10MB file size limit
- Automatic filename generation: `{prefix}_{code}_{index}.{extension}`

## Data Flow

1. User selects prefix (BA/BU) and enters code
2. Folder name auto-generates as `{prefix}_{code}`
3. User captures photos via camera or selects from gallery
4. Images are previewed with new filename format
5. On sync, files are uploaded to S3 with renamed filenames
6. Upload session is recorded in database

## External Dependencies

### Cloud Services
- **AWS S3**: Primary file storage solution
- **Neon Database**: PostgreSQL hosting (configured for serverless)

### Key Libraries
- **Frontend**: React, Vite, Tailwind CSS, Radix UI, React Query
- **Backend**: Express, Drizzle ORM, AWS SDK, Multer
- **Development**: TypeScript, ESBuild for production builds

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `AWS_ACCESS_KEY_ID`: AWS credentials for S3
- `AWS_SECRET_ACCESS_KEY`: AWS credentials for S3
- `AWS_REGION`: AWS region (defaults to us-east-1)
- `S3_BUCKET_NAME`: Target S3 bucket name

## Deployment Strategy

### Build Process
- Frontend: Vite builds to `dist/public`
- Backend: ESBuild bundles server code to `dist/index.js`
- Database: Drizzle migrations stored in `migrations/` directory

### Development
- `npm run dev`: Starts development server with hot reloading
- `npm run db:push`: Pushes schema changes to database
- Vite dev server integrated with Express for seamless development

### Production
- `npm run build`: Creates production builds for both frontend and backend
- `npm start`: Runs production server
- Database migrations handled via Drizzle Kit

### Architecture Decisions

**Monorepo Structure**: Frontend and backend in single repository with shared types and schemas for easier development and deployment.

**Drizzle ORM**: Chosen for type-safe database operations and excellent TypeScript integration over traditional ORMs.

**AWS S3**: Selected for reliable, scalable file storage with proper file naming conventions for organization.

**shadcn/ui**: Provides consistent, accessible UI components with full customization capabilities while maintaining design system consistency.

**React Query**: Handles server state management, caching, and synchronization efficiently for better user experience.

**Vite**: Fast development experience with HMR and efficient production builds, integrated with Express for unified development workflow.